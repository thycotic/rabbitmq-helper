# Examples

Please view the [documentation](https://thycotic.github.io/rabbitmq-helper/) for use cases and examples.

## Development/local PFX and CA certificate

The example Development/local PFX and CA certificate can be used for testing but should not be used in production.

