Due to the size and licensing of the erlang and rabbitmq installers,they are not committed this folder. You can download them and place them here.

Name them o-erlang.exe and o-rabbitMq.exe respectively. 

You can use the following helper commands for download locations

Get-DownloadLocations
Get-DownloadLocations -UseThycoticMirror